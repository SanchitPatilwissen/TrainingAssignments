package implementation;

public enum CarType{
    SUV, SEDAN, BUS, TRUCK
}