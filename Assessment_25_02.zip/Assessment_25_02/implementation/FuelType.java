package implementation;

public enum FuelType{
    PETROL, DIESEL, CNG, EV,  POWER
}