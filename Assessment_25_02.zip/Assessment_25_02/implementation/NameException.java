package implementation;

public class NameException extends RuntimeException {
   NameException() {
   }

   NameException(String var1) {
      super(var1);
   }
}
